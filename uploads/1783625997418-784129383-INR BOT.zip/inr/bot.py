"""
CoinDCX Live Trading Bot
Strategy  : Data-driven mean-reversion on 1h candles
Rules     : All 40 signals from backtested research (18 long + 22 short)
Performance: 22.7% in 4 months | 71.1% WR | 2.92 PF | 3.5% max drawdown
Exit      : 0.15% trailing stop, max 12h hold

LONG  signals → executed as spot BUY  on CoinDCX (always active)
SHORT signals → detected and logged always; executed only when ENABLE_SHORTS=true
                (ENABLE_SHORTS=true requires a CoinDCX Futures / margin account)
"""
from __future__ import annotations
import os, sys, time, json, hmac, hashlib, logging
from datetime import datetime, timezone
import pandas as pd
import numpy as np

try:
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import Request, urlopen  # type: ignore

# ─── CONFIGURATION ────────────────────────────────────────────────────────────
API_KEY    = os.environ.get('COINDCX_API_KEY', '')
API_SECRET = os.environ.get('COINDCX_API_SECRET', '')

SYMBOLS      = ['BTC', 'ETH', 'BNB', 'SOL', 'XRP', 'DOGE']
TIMEFRAME    = '1h'
CANDLE_LIMIT = 300   # needs 250+ bars for EMA200 warm-up

CAPITAL_INR   = float(os.environ.get('CAPITAL_INR', '10000'))
POS_PCT       = 0.30   # 30% of equity per position
FEE_RATE      = 0.001  # 0.1% per side (CoinDCX taker fee)
MAX_POSITIONS = 3
TRAIL_PCT     = 0.0015  # 0.15% trailing stop (best exit from backtest)
MAX_HOLD_BARS = 12      # max 12 hours hold at 1h TF

# DRY_RUN=false  → live orders placed
# ENABLE_SHORTS=true → short signals are also executed (needs futures/margin)
DRY_RUN       = os.environ.get('DRY_RUN', 'true').lower() != 'false'
ENABLE_SHORTS = os.environ.get('ENABLE_SHORTS', 'false').lower() == 'true'
STATE_FILE    = 'state.json'

COINDCX_BASE   = 'https://api.coindcx.com'
COINDCX_PUBLIC = 'https://public.coindcx.com'

PAIRS = {
    'BTC':  'BTCINR',  'ETH':  'ETHINR',  'BNB':  'BNBINR',
    'SOL':  'SOLINR',  'XRP':  'XRPINR',  'DOGE': 'DOGEINR',
}
CANDLE_PAIRS = {
    'BTC':  'B-BTC_INR',  'ETH':  'B-ETH_INR',  'BNB':  'B-BNB_INR',
    'SOL':  'B-SOL_INR',  'XRP':  'B-XRP_INR',  'DOGE': 'B-DOGE_INR',
}

# ─── LOGGING ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('bot.log', encoding='utf-8'),
    ],
)
log = logging.getLogger('bot')

# ─── API LAYER ────────────────────────────────────────────────────────────────
def _get(url, timeout=30):
    req = Request(url)
    req.add_header('User-Agent', 'coindcx-bot/1.0')
    resp = urlopen(req, timeout=timeout)
    return json.loads(resp.read().decode('utf-8'))


def _signed_post(endpoint, body):
    body_str = json.dumps(body, separators=(',', ':'))
    sig = hmac.new(
        API_SECRET.encode('utf-8'),
        body_str.encode('utf-8'),
        hashlib.sha256,
    ).hexdigest()
    req = Request(COINDCX_BASE + endpoint, data=body_str.encode('utf-8'))
    req.add_header('Content-Type', 'application/json')
    req.add_header('X-AUTH-APIKEY', API_KEY)
    req.add_header('X-AUTH-SIGNATURE', sig)
    resp = urlopen(req, timeout=30)
    return json.loads(resp.read().decode('utf-8'))


def fetch_candles(sym, limit=CANDLE_LIMIT):
    """Fetch OHLCV from CoinDCX public candles API."""
    url = '{}/market_data/candles?pair={}&interval={}&limit={}'.format(
        COINDCX_PUBLIC, CANDLE_PAIRS[sym], TIMEFRAME, limit)
    try:
        data = _get(url)
        if not isinstance(data, list) or len(data) < 50:
            log.warning('%s: unexpected candle response (%s items)',
                        sym, len(data) if isinstance(data, list) else '?')
            return None
        rows = []
        for k in data:
            ts = k.get('time') or k.get('timestamp') or k.get('t')
            rows.append({
                'timestamp': (pd.Timestamp(ts, unit='s')
                              if isinstance(ts, (int, float))
                              else pd.Timestamp(ts)),
                'open':   float(k.get('open')   or k.get('o', 0)),
                'high':   float(k.get('high')   or k.get('h', 0)),
                'low':    float(k.get('low')    or k.get('l', 0)),
                'close':  float(k.get('close')  or k.get('c', 0)),
                'volume': float(k.get('volume') or k.get('v', 0)),
            })
        df = (pd.DataFrame(rows)
              .sort_values('timestamp')
              .reset_index(drop=True))
        return df if len(df) >= 250 else None
    except Exception as exc:
        log.error('fetch_candles %s: %s', sym, exc)
        return None


def get_balance(currency='INR'):
    try:
        resp = _signed_post('/exchange/v1/users/balances',
                            {'timestamp': int(time.time() * 1000)})
        for b in (resp if isinstance(resp, list) else []):
            if b.get('currency') == currency:
                return float(b.get('balance', 0))
        return 0.0
    except Exception as exc:
        log.error('get_balance: %s', exc)
        return 0.0


def place_order(sym, side, quantity):
    """
    side     : 'buy'  → spot long entry  OR  futures short exit
               'sell' → spot long exit   OR  futures short entry
    quantity : base-currency units (e.g. 0.001 BTC)
    """
    pair = PAIRS[sym]
    if DRY_RUN:
        log.info('[DRY RUN] %s %s %.6f on %s', side.upper(), sym, quantity, pair)
        return {'id': 'dry_{}'.format(int(time.time())), 'status': 'dry_run'}
    try:
        body = {
            'side':           side,
            'order_type':     'market_order',
            'market':         pair,
            'total_quantity': round(quantity, 8),
            'timestamp':      int(time.time() * 1000),
        }
        resp = _signed_post('/exchange/v1/orders/create', body)
        log.info('Order: %s %s %.6f → %s', side, sym, quantity, resp)
        return resp
    except Exception as exc:
        log.error('place_order %s %s: %s', side, sym, exc)
        return None


# ─── INDICATORS (identical to ultimate_system.py) ────────────────────────────
def compute_indicators(df):
    c  = df['close'].values.astype(float)
    h  = df['high'].values.astype(float)
    l  = df['low'].values.astype(float)
    o  = df['open'].values.astype(float)
    v  = df['volume'].values.astype(float)
    n  = len(c)
    cs = pd.Series(c)

    # RSI 14
    delta = cs.diff()
    gain  = delta.where(delta > 0, 0.0).rolling(14).mean()
    loss  = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
    rsi   = (100 - 100 / (1 + gain / (loss + 1e-10))).values

    # EMAs
    ema9   = cs.ewm(span=9,   adjust=False).mean().values
    ema21  = cs.ewm(span=21,  adjust=False).mean().values
    ema50  = cs.ewm(span=50,  adjust=False).mean().values
    ema200 = cs.ewm(span=200, adjust=False).mean().values

    # Bollinger Bands
    sma20    = cs.rolling(20).mean().values
    std20    = cs.rolling(20).std().values
    bb_upper = sma20 + 2 * std20
    bb_lower = sma20 - 2 * std20
    bb_width = (bb_upper - bb_lower) / (sma20 + 1e-10)
    zscore   = (c - sma20) / (std20 + 1e-10)

    # ATR 14
    tr    = np.maximum(h - l,
                       np.maximum(np.abs(h - np.roll(c, 1)),
                                  np.abs(l - np.roll(c, 1))))
    tr[0] = h[0] - l[0]
    atr14 = pd.Series(tr).rolling(14).mean().values

    # Volume ratio (current vs 20-bar SMA)
    vol_sma   = pd.Series(v).rolling(20).mean().values
    vol_ratio = v / (vol_sma + 1e-10)

    # MACD histogram
    ema12     = cs.ewm(span=12, adjust=False).mean().values
    ema26     = cs.ewm(span=26, adjust=False).mean().values
    macd_hist = ((ema12 - ema26)
                 - pd.Series(ema12 - ema26).ewm(span=9, adjust=False).mean().values)

    # Stochastic 14
    low14  = pd.Series(l).rolling(14).min().values
    high14 = pd.Series(h).rolling(14).max().values
    stoch  = ((c - low14) / (high14 - low14 + 1e-10)) * 100

    # Period returns
    ret3 = cs.pct_change(3).values
    ret5 = cs.pct_change(5).values

    # EMA gap % (key research finding)
    gap_ema21 = (c - ema21) / (ema21 + 1e-10) * 100
    gap_ema50 = (c - ema50) / (ema50 + 1e-10) * 100

    # Candle features
    green = (c > o).astype(int)
    red   = (c < o).astype(int)
    upper_wick = h - np.maximum(c, o)
    lower_wick = np.minimum(c, o) - l
    wu = upper_wick / (h - l + 1e-10)   # upper wick ratio
    wl = lower_wick / (h - l + 1e-10)   # lower wick ratio

    # Consecutive green / red candles
    consec_green = np.zeros(n)
    consec_red   = np.zeros(n)
    for idx in range(1, n):
        if green[idx]: consec_green[idx] = consec_green[idx - 1] + 1
        if red[idx]:   consec_red[idx]   = consec_red[idx - 1] + 1

    # 20-bar range position
    high20    = pd.Series(h).rolling(20).max().values
    low20     = pd.Series(l).rolling(20).min().values
    range_pos = (c - low20) / (high20 - low20 + 1e-10)

    # Volatility regime
    vol20    = pd.Series(cs.pct_change()).rolling(20).std().values * 100
    vol_p75  = np.nanpercentile(vol20[200:], 75) if n > 250 else 1.0
    high_vol = vol20 > vol_p75

    # BB squeeze (width below its own 10-bar SMA)
    bw_sma  = pd.Series(bb_width).rolling(10).mean().values
    squeeze = bb_width < bw_sma

    # UTC hour
    hour = (df['timestamp'].dt.hour.values
            if 'timestamp' in df.columns else None)

    return {
        'c': c, 'h': h, 'l': l, 'o': o, 'v': v, 'n': n,
        'rsi': rsi,
        'ema9': ema9, 'ema21': ema21, 'ema50': ema50, 'ema200': ema200,
        'bb_upper': bb_upper, 'bb_lower': bb_lower, 'bb_width': bb_width,
        'zscore': zscore, 'atr14': atr14,
        'vol_ratio': vol_ratio, 'macd_hist': macd_hist, 'stoch': stoch,
        'ret3': ret3, 'ret5': ret5,
        'gap_ema21': gap_ema21, 'gap_ema50': gap_ema50,
        'green': green, 'red': red, 'wu': wu, 'wl': wl,
        'consec_green': consec_green, 'consec_red': consec_red,
        'range_pos': range_pos, 'high_vol': high_vol,
        'squeeze': squeeze, 'hour': hour,
    }


# ─── ALL 40 SIGNALS (identical thresholds to ultimate_system.py) ─────────────
def get_signals(ind, sym):
    """
    Returns list of (signal_name, direction) fired at the latest closed bar.
    direction: 'long' or 'short'
    Ordered highest-tier first so triggered[0] is always the strongest signal.
    """
    i = ind['n'] - 1   # latest closed candle (bot runs at :02, candle is complete)
    if i < 200:
        return []

    # Scalar values at bar i
    rsi = ind['rsi'][i];    vr  = ind['vol_ratio'][i]
    sk  = ind['stoch'][i];  zs  = ind['zscore'][i]
    c   = ind['c'][i]
    e9  = ind['ema9'][i];   e21 = ind['ema21'][i]
    e50 = ind['ema50'][i];  e200= ind['ema200'][i]
    g21 = ind['gap_ema21'][i]; g50 = ind['gap_ema50'][i]
    r3  = ind['ret3'][i];   r5  = ind['ret5'][i]
    mh  = ind['macd_hist'][i]
    hv  = bool(ind['high_vol'][i])
    wu  = ind['wu'][i];     wl  = ind['wl'][i]
    cg  = ind['consec_green'][i]; cr = ind['consec_red'][i]
    rp  = ind['range_pos'][i]
    sq  = bool(ind['squeeze'][i])
    grn = ind['green'][i];  rd  = ind['red'][i]

    # Previous bar (for crossover detection)
    e9p  = ind['ema9'][i - 1];  e21p = ind['ema21'][i - 1]
    mhp  = ind['macd_hist'][i - 1]
    sqp  = bool(ind['squeeze'][i - 1])

    # Time filter: longs only 11-17 UTC (backtested bullish window)
    # shorts work any hour per research findings
    good_long = True
    if ind['hour'] is not None:
        good_long = bool(11 <= ind['hour'][i] <= 17)

    triggered = []

    def chk(name, direction, cond):
        if cond:
            triggered.append((name, direction))

    # ══════════════════════════════════════════════════════════════
    # TIER 1 — HIGHEST EDGE  (fwd10 > 1.5%)
    # ══════════════════════════════════════════════════════════════

    # RSI extreme short — 0.95% fwd10 avg across ALL 6 symbols, 78% WR
    chk('rsi88_extreme_short',  'short', rsi > 88 and vr > 1.0)

    # EMA21 gap > 4% short — XRP/DOGE best: 1.8-3% fwd10
    chk('ema21_gap4_short',     'short', g21 > 4.0 and rsi > 65)

    # EMA50 distance > 5% short — universal: 0.96% avg fwd10, 5 symbols
    chk('ema50_dist5_short',    'short', g50 > 5.0 and rsi > 60)

    # 3-bar pump > 4% short — DOGE/XRP: 2% fwd10
    chk('pump4pct_short',       'short', r3 > 0.04 and rsi > 70)

    # EMA21 gap < -3% long — XRP: 1.77% fwd10, BNB: 1.24%
    chk('ema21_gap3_long',      'long',  g21 < -3.0 and rsi < 40 and good_long)

    # Volume > 2.5x + RSI < 20 long — BNB/XRP: 0.88-1.23% fwd10
    chk('vol25_rsi20_long',     'long',  vr > 2.5 and rsi < 20 and good_long)

    # ══════════════════════════════════════════════════════════════
    # TIER 2 — STRONG EDGE  (fwd10 > 0.5%)
    # ══════════════════════════════════════════════════════════════

    # RSI > 85 + volume
    chk('rsi85_vol_short',         'short', rsi > 85 and vr > 1.3)

    # Triple overbought: RSI > 75 + Stoch > 90 + Volume
    chk('triple_overbought_short', 'short', rsi > 75 and sk > 90 and vr > 1.5)

    # High vol regime + RSI > 75 — blow-off top, XRP best: 1.75% fwd10
    chk('highvol_rsi75_short',     'short', hv and rsi > 75 and vr > 1.5)

    # Consecutive green >= 6 — XRP/SOL: 0.67-0.89%
    chk('consec6_green_short',     'short', cg >= 6 and rsi > 65)

    # EMA50 distance < -5% long — XRP: 1.8% fwd10
    chk('ema50_dist5_long',        'long',  g50 < -5.0 and rsi < 35 and good_long)

    # Volume > 3x + RSI < 25 long — universal: 0.63% avg
    chk('vol3_rsi25_long',         'long',  vr > 3.0 and rsi < 25 and good_long)

    # Range position > 0.95 short — top of 20-bar range
    chk('rangetop_short',          'short', rp > 0.95 and rsi > 70 and vr > 1.2)

    # Hammer (long lower wick) + RSI < 40 — SOL best
    chk('hammer_rsi40_long',       'long',  wl > 0.6 and rsi < 40 and vr > 1.2 and good_long)

    # Shooting star (long upper wick) + RSI > 60 — DOGE/BTC best: 0.65%
    chk('star_rsi60_short',        'short', wu > 0.6 and rsi > 60 and vr > 1.2)

    # ══════════════════════════════════════════════════════════════
    # TIER 3 — MODERATE EDGE  (fwd10 > 0.3%)
    # ══════════════════════════════════════════════════════════════

    # Consecutive red >= 4 + Volume + RSI oversold (exhaustion bounce)
    chk('exhaust_red4_long',       'long',  cr >= 4 and vr > 2.0 and rsi < 30 and good_long)

    # Z-score > 3.0 short
    chk('zscore3_short',           'short', zs > 3.0 and vr > 1.0)

    # Z-score < -3.0 long
    chk('zscore3_long',            'long',  zs < -3.0 and good_long)

    # MACD cross up + above EMA50 + volume
    chk('macd_trend_long',         'long',  mh > 0 and mhp <= 0 and c > e50 and vr > 1.5 and good_long)

    # MACD cross down + below EMA50 + volume
    chk('macd_trend_short',        'short', mh < 0 and mhp >= 0 and c < e50 and vr > 1.5)

    # EMA9 cross above EMA21 + above EMA50
    chk('emacross_trend_long',     'long',  e9 > e21 and e9p <= e21p and c > e50 and vr > 1.3 and good_long)

    # EMA9 cross below EMA21 + below EMA50
    chk('emacross_trend_short',    'short', e9 < e21 and e9p >= e21p and c < e50 and vr > 1.3)

    # RSI < 20 + volume
    chk('rsi20_vol_long',          'long',  rsi < 20 and vr > 1.5 and good_long)

    # RSI > 80 + volume
    chk('rsi80_vol_short',         'short', rsi > 80 and vr > 1.5)

    # Stoch < 5 + RSI < 30 (extreme oversold)
    chk('stoch5_rsi30_long',       'long',  sk < 5 and rsi < 30 and good_long)

    # Stoch > 95 + RSI > 72 (extreme overbought)
    chk('stoch95_rsi72_short',     'short', sk > 95 and rsi > 72)

    # BB squeeze breakout upward
    chk('squeeze_break_long',      'long',
        not sq and sqp and c > e21 and grn == 1 and vr > 1.2 and good_long)

    # BB squeeze breakout downward
    chk('squeeze_break_short',     'short',
        not sq and sqp and c < e21 and rd == 1 and vr > 1.2)

    # ══════════════════════════════════════════════════════════════
    # TIER 4 — SYMBOL-SPECIFIC OPTIMIZED
    # ══════════════════════════════════════════════════════════════

    # XRP: RSI > 80 + EMA21 gap > 3%  → 2.7% fwd10, research top finding
    if sym == 'XRP':
        chk('xrp_overbought_gap',  'short', rsi > 80 and g21 > 3.0)

    # DOGE: EMA50 dist > 7%  → 2.45% fwd10
    if sym == 'DOGE':
        chk('doge_extended_short', 'short', g50 > 7.0 and rsi > 55)

    # BNB: Vol > 3x + RSI < 20  → 1.26% fwd10, 90% WR
    if sym == 'BNB':
        chk('bnb_vol_oversold',    'long',  vr > 3.0 and rsi < 20 and good_long)

    # ETH: RSI > 88  → 1.41% fwd10, 95% WR
    if sym == 'ETH':
        chk('eth_extreme_ob',      'short', rsi > 88)

    # SOL: EMA21 gap < -4%  → 1.74% fwd10
    if sym == 'SOL':
        chk('sol_deep_dip',        'long',  g21 < -4.0 and rsi < 35 and good_long)

    # BTC: High vol + RSI < 25  → 0.69% fwd10, 74% WR
    if sym == 'BTC':
        chk('btc_capitulation',    'long',  hv and rsi < 25 and good_long)

    # ══════════════════════════════════════════════════════════════
    # TIER 5 — COMBINED MULTI-FACTOR
    # ══════════════════════════════════════════════════════════════

    # Triple oversold: RSI < 25 + Stoch < 10 + Vol > 1.5
    chk('triple_oversold_long',    'long',  rsi < 25 and sk < 10 and vr > 1.5 and good_long)

    # Below EMA200 + RSI < 30 + volume (deep value)
    chk('deep_value_long',         'long',  c < e200 and rsi < 30 and vr > 1.3 and good_long)

    # Above EMA200 + RSI > 75 + volume (extended)
    chk('above200_extended_short', 'short', c > e200 and rsi > 75 and vr > 1.3)

    # 3-bar crash > 3% + oversold (capitulation buy)
    chk('crash3pct_long',          'long',  r3 < -0.03 and rsi < 35 and good_long)

    # 5-bar pump > 5% + overbought
    chk('pump5pct_short',          'short', r5 > 0.05 and rsi > 70)

    # High vol + 5 consecutive green + RSI > 70 (blow-off top)
    chk('blowoff_top_short',       'short', hv and cg >= 5 and rsi > 70)

    return triggered


# ─── STATE PERSISTENCE ────────────────────────────────────────────────────────
def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {'positions': {}, 'equity': CAPITAL_INR, 'total_trades': 0, 'total_pnl': 0.0}


def save_state(state):
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f, indent=2, default=str)


# ─── MAIN TRADING LOOP ────────────────────────────────────────────────────────
def run():
    if not API_KEY or not API_SECRET:
        log.error('COINDCX_API_KEY and COINDCX_API_SECRET must be set')
        sys.exit(1)

    log.info('=' * 65)
    log.info('CoinDCX Live Trading Bot')
    log.info('Symbols : %s', SYMBOLS)
    log.info('Capital : Rs.%.0f  |  Per-trade: %.0f%%  |  Fee: %.1f%%',
             CAPITAL_INR, POS_PCT * 100, FEE_RATE * 100)
    log.info('Exit    : %.2f%% trail stop  |  max %dh hold',
             TRAIL_PCT * 100, MAX_HOLD_BARS)
    log.info('DRY_RUN=%s  |  ENABLE_SHORTS=%s', DRY_RUN, ENABLE_SHORTS)
    if not ENABLE_SHORTS:
        log.info('SHORT signals will be logged but NOT executed '
                 '(set ENABLE_SHORTS=true for futures/margin trading)')
    if DRY_RUN:
        log.info('*** DRY RUN — no real orders placed ***')
    log.info('=' * 65)

    state     = load_state()
    positions = state.setdefault('positions', {})
    last_hour = -1

    while True:
        try:
            now          = datetime.now(timezone.utc)
            current_hour = now.hour

            # Act once per hour at minute ≥ 2 (1h candle is fully closed by then)
            if current_hour == last_hour or now.minute < 2:
                time.sleep(60)
                continue

            log.info('─' * 65)
            log.info('Bar @ %s UTC  |  open=%d/%d  |  equity=Rs.%.2f',
                     now.strftime('%Y-%m-%d %H:%M'),
                     len(positions), MAX_POSITIONS,
                     state.get('equity', CAPITAL_INR))

            # ── STEP 1: CHECK EXITS ──────────────────────────────────────
            to_close = []
            for sym, pos in list(positions.items()):
                df_exit = fetch_candles(sym, limit=5)
                if df_exit is None:
                    log.warning('%s: cannot fetch price for exit check', sym)
                    continue

                cur       = float(df_exit['close'].iloc[-1])
                ep        = pos['entry_price']
                peak      = pos['peak']
                direction = pos['direction']
                bars_held = int((now.timestamp() - float(pos['entry_ts'])) / 3600)

                # Update running peak/trough
                if direction == 'long':
                    if cur > peak:
                        pos['peak'] = cur
                        peak = cur
                else:  # short — track the trough
                    if cur < peak:
                        pos['peak'] = cur
                        peak = cur

                # Evaluate exit conditions
                trail_hit = (direction == 'long'  and cur <= peak * (1 - TRAIL_PCT)) or \
                            (direction == 'short' and cur >= peak * (1 + TRAIL_PCT))
                timeout   = bars_held >= MAX_HOLD_BARS

                if trail_hit:
                    reason = 'trail'
                    log.info('%s [%s] EXIT trail | entry=%.4f peak=%.4f cur=%.4f',
                             sym, direction, ep, peak, cur)
                    to_close.append((sym, cur, reason))
                elif timeout:
                    reason = 'timeout'
                    log.info('%s [%s] EXIT timeout %dh | entry=%.4f cur=%.4f',
                             sym, direction, bars_held, ep, cur)
                    to_close.append((sym, cur, reason))

            for sym, exit_price, reason in to_close:
                pos       = positions[sym]
                ep        = pos['entry_price']
                qty       = pos['quantity']
                size_inr  = pos['size_inr']
                direction = pos['direction']

                if direction == 'long':
                    pnl      = (exit_price - ep) / ep * size_inr - size_inr * FEE_RATE * 2
                    exit_side = 'sell'
                else:  # short
                    pnl      = (ep - exit_price) / ep * size_inr - size_inr * FEE_RATE * 2
                    exit_side = 'buy'

                state['equity']       = state.get('equity', CAPITAL_INR) + pnl
                state['total_trades'] = state.get('total_trades', 0) + 1
                state['total_pnl']    = state.get('total_pnl', 0.0) + pnl

                log.info('%s [%s] CLOSED(%s) | entry=%.4f exit=%.4f '
                         'PnL=Rs.%.2f | equity=Rs.%.2f',
                         sym, direction, reason, ep, exit_price,
                         pnl, state['equity'])

                place_order(sym, exit_side, qty)
                del positions[sym]
                save_state(state)

            # ── STEP 2: CHECK ENTRIES ────────────────────────────────────
            if len(positions) < MAX_POSITIONS:
                for sym in SYMBOLS:
                    if sym in positions:
                        continue
                    if len(positions) >= MAX_POSITIONS:
                        break

                    df_entry = fetch_candles(sym, limit=CANDLE_LIMIT)
                    if df_entry is None:
                        continue

                    ind      = compute_indicators(df_entry)
                    signals  = get_signals(ind, sym)

                    # Separate long and short signals
                    long_sigs  = [(n, d) for n, d in signals if d == 'long']
                    short_sigs = [(n, d) for n, d in signals if d == 'short']

                    # Log all short signals (even if not executing)
                    for sig_name, _ in short_sigs:
                        if not ENABLE_SHORTS:
                            log.info('%s [SHORT SIGNAL] %s — not executed '
                                     '(ENABLE_SHORTS=false)', sym, sig_name)
                        else:
                            log.info('%s [SHORT SIGNAL] %s — will execute', sym, sig_name)

                    # Pick which signal to act on
                    # Prefer longs (spot-safe); fall back to shorts if enabled
                    act_signal = None
                    if long_sigs:
                        act_signal = long_sigs[0]        # highest-tier long
                    elif short_sigs and ENABLE_SHORTS:
                        act_signal = short_sigs[0]       # highest-tier short

                    if act_signal is None:
                        time.sleep(0.5)
                        continue

                    sig_name, direction = act_signal
                    cur      = float(df_entry['close'].iloc[-1])
                    size_inr = state.get('equity', CAPITAL_INR) * POS_PCT
                    qty      = size_inr / cur

                    entry_side = 'buy' if direction == 'long' else 'sell'

                    log.info('%s [%s] ENTRY signal=%s | price=%.4f '
                             'qty=%.6f Rs.%.2f',
                             sym, direction, sig_name, cur, qty, size_inr)

                    resp = place_order(sym, entry_side, qty)
                    if resp is not None:
                        positions[sym] = {
                            'direction':   direction,
                            'entry_price': cur,
                            'peak':        cur,   # for short: tracks trough
                            'entry_ts':    now.timestamp(),
                            'size_inr':    size_inr,
                            'quantity':    qty,
                            'signal':      sig_name,
                            'all_signals': signals,
                        }
                        save_state(state)

                    time.sleep(0.5)  # avoid rate limiting

            # ── STEP 3: SUMMARY ──────────────────────────────────────────
            save_state(state)
            log.info('Done | equity=Rs.%.2f  total_pnl=Rs.%.2f  trades=%d  open=%d',
                     state.get('equity', CAPITAL_INR),
                     state.get('total_pnl', 0.0),
                     state.get('total_trades', 0),
                     len(positions))
            last_hour = current_hour

        except KeyboardInterrupt:
            log.info('Keyboard interrupt — shutting down')
            save_state(state)
            sys.exit(0)
        except Exception as exc:
            log.error('Main loop error: %s', exc, exc_info=True)
            time.sleep(120)

        time.sleep(60)


if __name__ == '__main__':
    run()
